package com.taskforge.monitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.io.RandomAccessFile
import java.util.Locale

private val Bg = Color(0xFF101216)
private val Panel = Color(0xFF1A1D23)
private val Cyan = Color(0xFF8FB4F8)
private val Purple = Color(0xFFB0A5D8)
private val Green = Color(0xFF8FC7A5)
private val Orange = Color(0xFFD7B27A)
private val Muted = Color(0xFF9299A5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TaskForgeApp(this) }
    }
}

data class Snapshot(
    val ramUsed: Long, val ramTotal: Long, val storageUsed: Long, val storageTotal: Long,
    val battery: Int, val cpu: Float
)

private fun readCpu(): Float {
    return try {
        RandomAccessFile("/proc/stat", "r").use { file ->
            val line = file.readLine().trim().split(Regex("\\s+"))
            val values = line.drop(1).take(8).map { it.toLong() }
            val idle = values[3] + values.getOrElse(4) { 0L }
            val total = values.sum()
            Thread.sleep(250)
            file.seek(0)
            val line2 = file.readLine().trim().split(Regex("\\s+"))
            val values2 = line2.drop(1).take(8).map { it.toLong() }
            val idle2 = values2[3] + values2.getOrElse(4) { 0L }
            val total2 = values2.sum()
            val diffTotal = (total2 - total).coerceAtLeast(1)
            (((diffTotal - (idle2 - idle)) * 100f) / diffTotal).coerceIn(0f, 100f)
        }
    } catch (_: Exception) { 0f }
}

private fun snapshot(context: Context): Snapshot {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    val stat = StatFs(context.filesDir.absolutePath)
    val totalStorage = stat.totalBytes
    val freeStorage = stat.availableBytes
    val battery = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
    return Snapshot(
        (mi.totalMem - mi.availMem).coerceAtLeast(0), mi.totalMem,
        (totalStorage - freeStorage).coerceAtLeast(0), totalStorage, level, readCpu()
    )
}

private fun fmt(bytes: Long): String {
    val gb = bytes / 1024.0 / 1024.0 / 1024.0
    return if (gb >= 1) String.format(Locale.getDefault(), "%.1f GB", gb)
    else String.format(Locale.getDefault(), "%.0f MB", bytes / 1024.0 / 1024.0)
}


@Composable
fun TaskForgeApp(context: Context) {
    var page by remember { mutableStateOf("Обзор") }
    var data by remember { mutableStateOf(snapshot(context)) }
    var history by remember { mutableStateOf(listOf(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f)) }
    LaunchedEffect(Unit) {
        while (true) {
            data = snapshot(context)
            history = (history + data.cpu).takeLast(24)
            delay(1800)
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Cyan, secondary = Purple,
        onBackground = Color(0xFFF1F2F4), onSurface = Color(0xFFF1F2F4),
        surfaceVariant = Color(0xFF252930), onSurfaceVariant = Muted
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFF171A20),
                    contentColor = Muted,
                    tonalElevation = 0.dp
                ) {
                    listOf("Обзор", "Приложения", "Система").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(when (item) {
                                    "Обзор" -> Icons.Default.Dashboard
                                    "Приложения" -> Icons.Default.Apps
                                    else -> Icons.Default.Memory
                                }, contentDescription = item)
                            },
                            label = { Text(item, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan,
                                selectedTextColor = Cyan,
                                indicatorColor = Color(0xFF293443),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize()
                    .background(Bg)
                    .padding(padding)
                    .padding(horizontal = 18.dp)
            ) {
                Spacer(Modifier.height(24.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "ТАСКФОРДЖ",
                            color = Muted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 2.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(page, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(Green, RoundedCornerShape(50)))
                        Spacer(Modifier.width(7.dp))
                        Text("Активно", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(20.dp))
                when (page) {
                    "Обзор" -> Overview(data, history)
                    "Приложения" -> AppsPage(context)
                    else -> SystemPage(context, data)
                }
            }
        }
    }
}

@Composable
fun Overview(s: Snapshot, history: List<Float>) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("ПРОЦЕССОР", "${s.cpu.toInt()}%", Cyan, Modifier.weight(1f), "Текущая загрузка")
                MetricCard("ЗАРЯД БАТАРЕИ", "${s.battery}%", Green, Modifier.weight(1f), "Уровень заряда")
            }
        }
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("МОНИТОРИНГ ПРОЦЕССОРА", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                        Text("Загрузка процессора", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("${s.cpu.toInt()}%", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(12.dp))
                Sparkline(history, Cyan, Modifier.fillMaxWidth().height(74.dp))
                Text("Обновление примерно каждые 2 секунды", color = Muted, fontSize = 11.sp)
            }
        }
        item {
            UsageCard("ОПЕРАТИВНАЯ ПАМЯТЬ", fmt(s.ramUsed), fmt(s.ramTotal), s.ramUsed.toFloat() / s.ramTotal.coerceAtLeast(1), Purple)
        }
        item {
            UsageCard("ПАМЯТЬ ТЕЛЕФОНА", fmt(s.storageUsed), fmt(s.storageTotal), s.storageUsed.toFloat() / s.storageTotal.coerceAtLeast(1), Orange)
        }
        item {
            PanelCard {
                Text("СОСТОЯНИЕ СИСТЕМЫ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                Spacer(Modifier.height(10.dp))
                StatusLine("Мониторинг системы", "Работает", Green)
                StatusLine("Доступ к показателям", "Разрешён системой Android", Cyan)
                StatusLine("Остановка других приложений", "Ограничено Android", Orange)
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, accent: Color, modifier: Modifier, subtitle: String) {
    PanelCard(modifier) {
        Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, color = accent, fontSize = 29.sp, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = Muted, fontSize = 10.sp)
    }
}

@Composable
fun UsageCard(title: String, used: String, total: String, fraction: Float, color: Color) {
    PanelCard {
        Text(title, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        Spacer(Modifier.height(9.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(used, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            Text("/ $total", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text("${(fraction * 100).toInt()}%", color = color, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { fraction.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp),
            color = color, trackColor = Color(0xFF343A44)
        )
    }
}

@Composable
fun PanelCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier = modifier.fillMaxWidth(), color = Panel, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun StatusLine(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color(0xFFD6DDF0), fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Sparkline(values: List<Float>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = size.width * i / (values.size - 1)
            val y = size.height - (v / 100f) * size.height
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawLine(Color(0xFF343A44), Offset(0f, size.height - 1), Offset(size.width, size.height - 1), 1.dp.toPx())
        drawPath(path, color, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx()))
    }
}

data class AppEntry(val name: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

@Composable
fun AppsPage(context: Context) {
    val pm = context.packageManager
    val apps = remember {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0).mapNotNull {
            val info = it.activityInfo.applicationInfo
            if (info.packageName == context.packageName) null
            else AppEntry(pm.getApplicationLabel(info).toString(), info.packageName, pm.getApplicationIcon(info))
        }.distinctBy { it.packageName }.sortedBy { it.name.lowercase() }
    }
    Column(Modifier.fillMaxSize()) {
        Text("Установленные приложения", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        if (apps.isEmpty()) Text("Не удалось получить список приложений", color = Muted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(apps) { app ->
                PanelCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(app.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        TextButton(onClick = {
                            val launch = pm.getLaunchIntentForPackage(app.packageName)
                            if (launch != null) context.startActivity(launch)
                        }) { Text("ЗАПУСТИТЬ", color = Cyan, fontSize = 11.sp) }
                        TextButton(onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = android.net.Uri.parse("package:${app.packageName}")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        }) { Text("ПАРАМЕТРЫ", color = Purple, fontSize = 10.sp) }
                    }
                    Text(app.packageName, color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
fun SystemPage(context: Context, s: Snapshot) {
    val version = android.os.Build.VERSION.RELEASE
    val model = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            PanelCard {
                Text("ИНФОРМАЦИЯ ОБ УСТРОЙСТВЕ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(model, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Android $version", color = Muted, fontSize = 12.sp)
            }
        }
        item { UsageCard("ОПЕРАТИВНАЯ ПАМЯТЬ", fmt(s.ramUsed), fmt(s.ramTotal), s.ramUsed.toFloat() / s.ramTotal.coerceAtLeast(1), Purple) }
        item { UsageCard("ПАМЯТЬ ПРИЛОЖЕНИЯ", fmt(s.storageUsed), fmt(s.storageTotal), s.storageUsed.toFloat() / s.storageTotal.coerceAtLeast(1), Orange) }
        item {
            PanelCard {
                Text("ДОПОЛНИТЕЛЬНЫЕ ДЕЙСТВИЯ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Button(onClick = { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                    Icon(Icons.Default.Settings, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Открыть настройки телефона")
                }
            }
        }
    }
}
